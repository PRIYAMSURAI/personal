﻿$(document).ready(function () {
    jQuery.support.cors = true;



    $.ajax({
        type: "GET",
        url: "http://localhost/API/api/Student",
        contentType: "application/json",
        dataType: "json",
        success: function (data) {

            $.each(data, function (key, value) {
                //stringify
                var jsonData = JSON.stringify(value);
                //Parse JSON
                var objData = $.parseJSON(jsonData);
                var id = objData.StudentID;
                var fname = objData.FirstName;
                var lname = objData.LastName;

                $('<tr><td>' + id + '</td><td>' + fname +'</td><td>' + lname + '</td></tr>').appendTo('#students');

            });
        },
        error: function (xhr) {
            alert(xhr.responseText);
        }
    });

})