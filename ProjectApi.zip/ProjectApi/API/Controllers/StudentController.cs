﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Net.Http.Formatting;

namespace API.Controllers
{
   
    public class StudentController : ApiController
    {
       [HttpGet]
        public List<API.PriyamItem> CartGet()
        {
            using (API.LibraryManagementEntities4 dc = new API.LibraryManagementEntities4())
            {
                return (dc.PriyamItems.ToList());
            }
        }

        [HttpPost]
        public List<string> CartPost(FormDataCollection form)
        {
            var productname = form.Get("productname");
            var Amount = form.Get("Amount");
            var quantity = form.Get("text");
            return null;
        }

        // POST api/values
        public void RegistrationPost(FormDataCollection form)
        {
            string studentName = form.Get("StudentName");
            string studentEmail = form.Get("StudentEmail");
            string studentContact = form.Get("StudentContact");
            string studentGender = form.Get("StudentGender");
            string studentCountry = form.Get("StudentCountry");
            string studentState = form.Get("StudentState");
            string studentCity = form.Get("StudentCity");
            string studentPassword = form.Get("StudentPassword");
            string studentDOB = form.Get("StudentDOB");
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}